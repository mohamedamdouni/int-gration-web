// Cart.js
import React from 'react';

const Cart = ({ cart, removeFromCart, total }) => {
  return (
    <div>
      <h2>Panier</h2>
      {cart.map((item) => (
        <div key={item.id}>
          <p>{item.name}</p>
          <p>{item.price} €</p>
          <button onClick={() => removeFromCart(item)}>Retirer du panier</button>
        </div>
      ))}
      <p>Total: {total} €</p>
    </div>
  );
};

export default Cart;
