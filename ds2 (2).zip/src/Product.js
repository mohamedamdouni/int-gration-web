
import React from 'react';
import './styles.css';

class Product extends React.Component {
  render() {
    const { name, price, addToCart } = this.props;
    return (
      <div >
        <h3>{name}</h3>
        <p>Price: ${price}</p>
        <button onClick={() => addToCart(name, price)}>Add to Cart</button>
      </div>
    );
  }
}

export default Product;
