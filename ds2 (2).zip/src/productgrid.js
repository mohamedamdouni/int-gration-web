import React from 'react';
import { BrowserRouter as Router , Link  } from 'react-router-dom';


 
const ProductGrid = () => {
  return (
   

    <section className="py-5 products-listing bg-light">
      <div className="container">
        <div className="row">
         <div class="col-md-3">
         <div>
            <div className="filters mobile-filters shadow-sm rounded bg-white mb-4 d-none d-block d-md-none">
              <input type="checkbox" className="custom-control-input" id="osahan111" />
                  <label className="custom-control-label" htmlFor="osahan111">Relevance </label>

<input type="checkbox" className="custom-control-input" id="osahan112" />
<label className="custom-control-label" htmlFor="osahan112">Price (Low to High)</label>

<input type="checkbox" className="custom-control-input" id="osahan113" />
<label className="custom-control-label" htmlFor="osahan113">Price (High to Low)</label>

<input type="checkbox" className="custom-control-input" id="osahan114" />
<label className="custom-control-label" htmlFor="osahan114">Discount (High to Low)</label>

<input type="checkbox" className="custom-control-input" id="osahan115" />
<label className="custom-control-label" htmlFor="osahan115">Name (A to Z)</label>

            </div>
            <div className="filters shadow-sm rounded bg-white mb-3 d-none d-sm-none d-md-block">
      <div className="filters-header border-bottom pl-4 pr-4 pt-3 pb-3">
        <h5 className="m-0 text-dark">Filter By</h5>
      </div>

      <div className="filters-body">
        <div id="accordion">
          <div className="filters-card border-bottom p-4">
            <div className="filters-card-header" id="headingTwo">
              <h6 className="mb-0">
                <a href="#" className="btn-link" data-toggle="collapse" data-target="#collapsetwo" aria-expanded="true" aria-controls="collapsetwo">
                  All Category
                  <i className="icofont-arrow-down float-right"></i>
                </a>
              </h6>
            </div>
            <div id="collapsetwo" className="collapse show" aria-labelledby="headingTwo" data-parent="#accordion">
              <div className="filters-card-body card-shop-filters">
                <form className="filters-search mb-3">
                  <div className="form-group">
                    <i className="icofont-search"></i>
                    <input type="text" className="form-control" placeholder="Start typing to search..." />
                  </div>
                </form>

                <div className="custom-control custom-checkbox">
                  <input type="checkbox" className="custom-control-input" id="osahan11q" />
                  <label className="custom-control-label" htmlFor="osahan11q">Jackets <small className="text-black-50">156</small></label>
                </div>

                <div className="custom-control custom-checkbox">
                  <input type="checkbox" className="custom-control-input" id="osahan11w" />
                  <label className="custom-control-label" htmlFor="osahan11w">Blazers & Coats <small className="text-black-50">120</small></label>
                </div>

                <div className="custom-control custom-checkbox">
                  <input type="checkbox" className="custom-control-input" id="osahan11e" />
                  <label className="custom-control-label" htmlFor="osahan11e">Suits <small className="text-black-50">130</small></label>
                </div>

                <div className="mt-2"><a href="#" className="link">See all</a></div>
              </div>
            </div>
          </div>

          <div className="filters-card border-bottom p-4">
            <div className="filters-card-header" id="headingOne">
              <h6 className="mb-0">
                <a href="#" className="btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                  Brand <i className="icofont-arrow-down float-right"></i>
                </a>
              </h6>
            </div>

            <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
              <div className="filters-card-body card-shop-filters">
                <div className="custom-control custom-checkbox">
                  <input type="checkbox" className="custom-control-input" id="osahan11z" />
                  <label className="custom-control-label" htmlFor="osahan11z">Brand 1 <small className="text-black-50">230</small></label>
                </div>

                <div className="custom-control custom-checkbox">
                  <input type="checkbox" className="custom-control-input" id="osahan11zz" />
                  <label className="custom-control-label" htmlFor="osahan11zz">Brand 2 <small className="text-black-50">95</small></label>
                </div>

                <div className="mt-2"><a href="#" className="link">See all</a></div>
              </div>
            </div>
          </div>

          <div className="filters-card border-bottom p-4">
            <div className="filters-card-header" id="headingOffer">
              <h6 className="mb-0">
                <a href="#" className="btn-link" data-toggle="collapse" data-target="#collapseOffer" aria-expanded="true" aria-controls="collapseOffer">
                  Price <i className="icofont-arrow-down float-right"></i>
                </a>
              </h6>
            </div>

            <div id="collapseOffer" className="collapse" aria-labelledby="headingOffer" data-parent="#accordion">
              <div className="filters-card-body card-shop-filters">
                <div className="custom-control custom-checkbox">
                  <input type="checkbox" className="custom-control-input" id="osahan11cc" />
                  <label className="custom-control-label" htmlFor="osahan11cc">Any Price </label>
                </div>

                <div className="custom-control custom-checkbox">
                  <input type="checkbox" className="custom-control-input" id="osahan11c" />
                  <label className="custom-control-label" htmlFor="osahan11c">$50 - $100</label>
                </div>

                <div className="custom-control custom-checkbox">
                  <input type="checkbox" className="custom-control-input" id="osahan11v" />
                  <label className="custom-control-label" htmlFor="osahan11v">$100 - $150</label>
                </div>

                <div className="custom-control custom-checkbox">
                  <input type="checkbox" className="custom-control-input" id="osahan11vv" />
                  <label className="custom-control-label" htmlFor="osahan11vv">$150 - $200</label>
                </div>

                <div className="mt-2"><a href="#" className="link">See all</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      

    </div>
         </div>
         </div>
         <div class="col-md-9">
            <div class="row">
            <div class="col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                    <span class="badge badge-danger">NEW</span>
                    <img src="img/item/1.png" height={350}class="card-img-top" alt="..."></img></a>
                                                                  

                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                    <span class="badge badge-danger">NEW</span>
                    <img src="img/item/2.png" height={350}class="card-img-top" alt="..."></img></a>
                                                                  

                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                    <span class="badge badge-danger">NEW</span>
                    <img src="img/item/3.png" height={350}class="card-img-top" alt="..."></img></a>
                                                                  

                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                    <span class="badge badge-danger">NEW</span>
                    <img src="img/item/4.png" height={350}class="card-img-top" alt="..."></img></a>
                                                                  

                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            </div>
            <div className="row">
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                    <span class="badge badge-danger">NEW</span>
                    <img src="img/item/5.png"  height={350}class="card-img-top" alt="..."></img></a>
                                                                  

                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                    <span class="badge badge-danger">NEW</span>
                    <img src="img/item/6.png" height={350}class="card-img-top" alt="..."></img></a>
                                                                  

                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                    <span class="badge badge-danger">NEW</span>
                    <img src="img/item/7.png" height={350}class="card-img-top" alt="..."></img></a>
                                                                  

                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                    <span class="badge badge-danger">NEW</span>
                    <img src="img/item/8.png" height={350}class="card-img-top" alt="..."></img></a>
                                                                  

                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            </div>

         </div>
          
            
            
        </div>
      </div>
        
      
    </section>
    
        
    
  );
};

export default ProductGrid;
