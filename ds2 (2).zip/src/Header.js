import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart } from '@fortawesome/free-solid-svg-icons';



const Header = () => (
  <header>
    <nav>
      {/* Your other navigation elements */}
      <FontAwesomeIcon icon={faShoppingCart} />
      {/* Additional navigation elements */}
    </nav>
  </header>
);

export default Header;
