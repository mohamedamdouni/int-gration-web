class Icone extends React.Component {
    render() {
      return (
        <div>
            <span class="fa-stack fa-sm">
             <i class="fa fa-circle fa-stack-2x blue-icon"></i>
             <i class="fa fa-thumbs-up fa-stack-1x fa-inverse"></i>
            </span>
        </div>
     )
    }
 }