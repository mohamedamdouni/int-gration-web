<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Gurdeep singh osahan">
      <meta name="author" content="Gurdeep singh osahan">
      <title>Chpoee - Bootstrap E-Commerce Template</title>
      <!-- Favicon Icon -->
      <link rel="icon" type="image/png" href="img/fav-icon.png">
      <!-- Bootstrap core CSS -->
      <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <!-- Select2 CSS -->
      <link href="vendor/select2/css/select2-bootstrap.css" />
      <link href="vendor/select2/css/select2.min.css" rel="stylesheet" />
      <!-- Font Awesome-->
      <link href="vendor/fontawesome/css/all.min.css" rel="stylesheet">
      <link href="vendor/icofont/icofont.min.css" rel="stylesheet">
      <!-- Custom styles for this template -->
      <link href="css/style.css" rel="stylesheet">
      <!-- Owl Carousel -->
      <link rel="stylesheet" href="vendor/owl-carousel/owl.carousel.css">
      <link rel="stylesheet" href="vendor/owl-carousel/owl.theme.css">
   </head>
   <body>
      <div class="bg-light shadow-sm">
        
         <div class="main-nav shadow-sm">
            <nav class="navbar navbar-expand-lg navbar-light bg-white pt-0 pb-0">
               <div class="container">
                  <a class="navbar-brand" href="index.html">
                  <img src="img/logo.png" alt="gurdeep osahan designer">
                  </a>
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                     <ul class="navbar-nav mr-auto main-nav-left">
                        <li class="nav-item">
                           <a class="nav-link" href="index.html"><i class="icofont-ui-home"></i></a>
                        </li>
                        <li class="nav-item dropdown mega-drop-main">
                           <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Decoration
                           </a>
                           <div class="dropdown-menu mega-drop  shadow-sm border-0" aria-labelledby="navbarDropdown">
                              <div class="row ml-0 mr-0">
                                 <div class="col-lg-2 col-md-2">
                                    <div class="mega-list">
                                       <a class="mega-title" href="product-grid.html">Home Decoration</a>
                                       <a href="product-grid.html">House</a>
                                       <a href="product-grid.html">Garden</a>
                                       
                                      
                                    </div>
                                 </div>
                                
                              </div>
                           </div>
                        </li>
                        <li class="nav-item dropdown mega-drop-main">
                           <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Art</a>
                           <div class="dropdown-menu mega-drop  shadow-sm border-0" aria-labelledby="navbarDropdown">
                              <div class="row ml-0 mr-0">
                                 <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                                    <div class="mega-list">
                                       <a class="mega-title" href="product-grid.html">Pottery </a>
                                       <a href="product-grid.js">Bowel</a>
                                       <a href="product-grid.js">Cups</a>
                                    
                                    </div>
                                 </div>
                               
                              </div>
                           </div>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="product-grid.html">SALE</a>
                        </li>
                        <li class="nav-item dropdown">
                           <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           PAGES
                           </a>
                           <div class="dropdown-menu dropdown-menu-right shadow-sm border-0">
                              <a class="dropdown-item" href="product-grid.html">Product List</a>
                              <a class="dropdown-item" href="product-detail.html">Product Detail</a>
                              <a class="dropdown-item" href="checkout.html">Checkout</a>
                              <a class="dropdown-item" href="profile.html">My Account</a>
                              <a class="dropdown-item" href="about-us.html">About Us</a>
                              <a class="dropdown-item" href="faq.html">FAQ</a>
                              <a class="dropdown-item" href="contact-us.html">Contact Us</a>
                           </div>
                        </li>
                     </ul>
                     <form class="form-inline my-2 my-lg-0 top-search">
                        <button class="btn-link" type="submit"><i class="icofont-search"></i></button>
                        <input class="form-control mr-sm-2" type="search" placeholder="Search for products, brands and more" aria-label="Search">
                     </form>
                     <ul class="navbar-nav ml-auto profile-nav-right">
                        <li class="nav-item dropdown">
                           <a class="nav-link ml-0 dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                           <img alt="Generic placeholder image" src="img/user/1.png" class="nav-osahan-pic rounded-pill"> My Account
                           </a>
                           <div class="dropdown-menu dropdown-menu-right shadow-sm border-0">
                              <a class="dropdown-item" href="profile.html"><i class="icofont-ui-user"></i> My Profile</a>
                              <a class="dropdown-item" href="profile.html"><i class="icofont-location-pin"></i> My Address</a>
                              <a class="dropdown-item" href="profile.html"><i class="icofont-heart"></i> Wish List</a>
                              <a class="dropdown-item" href="profile.html"><i class="icofont-list"></i> Order List</a>
                              <a class="dropdown-item" href="profile.html"><i class="icofont-file-document"></i> Order Status</a>
                              <a class="dropdown-item" href="profile.html"><i class="icofont-logout"></i> Logout</a>
                           </div>
                        </li>
                        <li class="nav-item cart-nav">
                           <a data-toggle="offcanvas" class="nav-link" href="#">
                           <i class="icofont-basket"></i> Cart
                           <span class="badge badge-danger">5</span>
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
            </nav>
         </div>
      </div>
      <section class="py-5 products-listing bg-light">
         <div class="container">
            <div class="row">
               <div class="col-md-3">
                  <div class="filters mobile-filters shadow-sm rounded bg-white mb-4 d-none d-block d-md-none">
                     <div class="border-bottom">
                        <a class="h6 font-weight-bold text-dark d-block m-0 p-3" data-toggle="collapse" href="#mobile-filters" role="button" aria-expanded="false" aria-controls="mobile-filters">Filter By <i class="icofont-arrow-down float-right mt-1"></i></a>
                     </div>
                     <div id="mobile-filters" class="filters-body collapse multi-collapse">
                        <div id="accordion">
                           <div class="filters-card border-bottom p-3">
                              <div class="filters-card-header" id="headingOffer">
                                 <h6 class="mb-0">
                                    <a href="#" class="btn-link" data-toggle="collapse" data-target="#collapseSort" aria-expanded="true" aria-controls="collapseSort">
                                    Sort by Products <i class="icofont-arrow-down float-right"></i>
                                    </a>
                                 </h6>
                              </div>
                              <div id="collapseSort" class="collapse" aria-labelledby="headingOffer" data-parent="#accordion">
                                 <div class="filters-card-body card-shop-filters">
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan111">
                                       <label class="custom-control-label" for="osahan111">Relevance </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan112">
                                       <label class="custom-control-label" for="osahan112">Price (Low to High)
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan113">
                                       <label class="custom-control-label" for="osahan113">Price (High to Low)
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan114">
                                       <label class="custom-control-label" for="osahan114">Discount (High to Low)
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan115">
                                       <label class="custom-control-label" for="osahan115">Name (A to Z)
                                       </label>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="filters-card border-bottom p-3">
                              <div class="filters-card-header" id="headingTwo">
                                 <h6 class="mb-0">
                                    <a href="#" class="btn-link" data-toggle="collapse" data-target="#collapsetwo" aria-expanded="true" aria-controls="collapsetwo">
                                    All Category
                                    <i class="icofont-arrow-down float-right"></i>
                                    </a>
                                 </h6>
                              </div>
                              <div id="collapsetwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                 <div class="filters-card-body card-shop-filters">
                                    <form class="filters-search mb-3">
                                       <div class="form-group">
                                          <i class="icofont-search"></i>                                 
                                          <input type="text" class="form-control" placeholder="Start typing to search...">
                                       </div>
                                    </form>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan116">
                                       <label class="custom-control-label" for="osahan116">Jackets <small class="text-black-50">156</small></label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan117">
                                       <label class="custom-control-label" for="osahan117">Blazers & Coats <small class="text-black-50">120</small></label>
                                    </div>
                                
                                    <div class="mt-2"><a href="#" class="link">See all</a></div>
                                 </div>
                              </div>
                           </div>
                           <div class="filters-card border-bottom p-3">
                              <div class="filters-card-header" id="headingOne">
                                 <h6 class="mb-0">
                                    <a href="#" class="btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    Brand <i class="icofont-arrow-down float-right"></i>
                                    </a>
                                 </h6>
                              </div>
                              <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                 <div class="filters-card-body card-shop-filters">
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan1155">
                                       <label class="custom-control-label" for="osahan1155">Brand 1 <small class="text-black-50">230</small>
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan1166">
                                       <label class="custom-control-label" for="osahan1166">Brand 2 <small class="text-black-50">95</small>
                                       </label>
                                    </div>
                                  
                                    <div class="mt-2"><a href="#" class="link">See all</a></div>
                                 </div>
                              </div>
                           </div>
                           <div class="filters-card border-bottom p-3">
                              <div class="filters-card-header" id="headingOffer">
                                 <h6 class="mb-0">
                                    <a href="#" class="btn-link" data-toggle="collapse" data-target="#collapseOffer" aria-expanded="true" aria-controls="collapseOffer">
                                    Price <i class="icofont-arrow-down float-right"></i>
                                    </a>
                                 </h6>
                              </div>
                              <div id="collapseOffer" class="collapse" aria-labelledby="headingOffer" data-parent="#accordion">
                                 <div class="filters-card-body card-shop-filters">
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan1100">
                                       <label class="custom-control-label" for="osahan1100">Any Price </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11111">
                                       <label class="custom-control-label" for="osahan11111">$50 - $100
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11222">
                                       <label class="custom-control-label" for="osahan11222">$100 - $150
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11333">
                                       <label class="custom-control-label" for="osahan11333">$150 - $200
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11444">
                                       <label class="custom-control-label" for="osahan11444">$200 - $1000
                                       </label>
                                    </div>
                                    <div class="mt-2"><a href="#" class="link">See all</a></div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="filters shadow-sm rounded bg-white mb-3 d-none d-sm-none d-md-block">
                     <div class="filters-header border-bottom pl-4 pr-4 pt-3 pb-3">
                        <h5 class="m-0 text-dark">Filter By</h5>
                     </div>
                     <div class="filters-body">
                        <div id="accordion">
                           <div class="filters-card border-bottom p-4">
                              <div class="filters-card-header" id="headingTwo">
                                 <h6 class="mb-0">
                                    <a href="#" class="btn-link" data-toggle="collapse" data-target="#collapsetwo" aria-expanded="true" aria-controls="collapsetwo">
                                    All Category
                                    <i class="icofont-arrow-down float-right"></i>
                                    </a>
                                 </h6>
                              </div>
                              <div id="collapsetwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordion">
                                 <div class="filters-card-body card-shop-filters">
                                    <form class="filters-search mb-3">
                                       <div class="form-group">
                                          <i class="icofont-search"></i>                                 
                                          <input type="text" class="form-control" placeholder="Start typing to search...">
                                       </div>
                                    </form>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11q">
                                       <label class="custom-control-label" for="osahan11q">Jackets <small class="text-black-50">156</small></label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11w">
                                       <label class="custom-control-label" for="osahan11w">Blazers & Coats <small class="text-black-50">120</small></label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11e">
                                       <label class="custom-control-label" for="osahan11e">Suits <small class="text-black-50">130</small></label>
                                    </div>
                                 
                                    <div class="mt-2"><a href="#" class="link">See all</a></div>
                                 </div>
                              </div>
                           </div>
                           <div class="filters-card border-bottom p-4">
                              <div class="filters-card-header" id="headingOne">
                                 <h6 class="mb-0">
                                    <a href="#" class="btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    Brand <i class="icofont-arrow-down float-right"></i>
                                    </a>
                                 </h6>
                              </div>
                              <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                 <div class="filters-card-body card-shop-filters">
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11z">
                                       <label class="custom-control-label" for="osahan11z">Brand 1 <small class="text-black-50">230</small>
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11zz">
                                       <label class="custom-control-label" for="osahan11zz">Brand 2 <small class="text-black-50">95</small>
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11zzz">
                                       <label class="custom-control-label" for="osahan11zzz">Brand 3 <small class="text-black-50">35</small>
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11x">
                                       <label class="custom-control-label" for="osahan11x">Brand 4 <small class="text-black-50">46</small>
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11xx">
                                       <label class="custom-control-label" for="osahan11xx">Brand 5 <small class="text-black-50">20</small></label>
                                    </div>
                                    <div class="mt-2"><a href="#" class="link">See all</a></div>
                                 </div>
                              </div>
                           </div>
                           <div class="filters-card border-bottom p-4">
                              <div class="filters-card-header" id="headingOffer">
                                 <h6 class="mb-0">
                                    <a href="#" class="btn-link" data-toggle="collapse" data-target="#collapseOffer" aria-expanded="true" aria-controls="collapseOffer">
                                    Price <i class="icofont-arrow-down float-right"></i>
                                    </a>
                                 </h6>
                              </div>
                              <div id="collapseOffer" class="collapse" aria-labelledby="headingOffer" data-parent="#accordion">
                                 <div class="filters-card-body card-shop-filters">
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11cc">
                                       <label class="custom-control-label" for="osahan11cc">Any Price </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11c">
                                       <label class="custom-control-label" for="osahan11c">$50 - $100
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11v">
                                       <label class="custom-control-label" for="osahan11v">$100 - $150
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11vv">
                                       <label class="custom-control-label" for="osahan11vv">$150 - $200
                                       </label>
                                    </div>
                                    <div class="custom-control custom-checkbox">
                                       <input type="checkbox" class="custom-control-input" id="osahan11gg">
                                       <label class="custom-control-label" for="osahan11gg">$200 - $1000
                                       </label>
                                    </div>
                                    <div class="mt-2"><a href="#" class="link">See all</a></div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
				
               </div>
               <div class="col-md-9">
                  <div class="shop-head mb-3">
                     <div class="btn-group float-right mt-2 d-none d-sm-none d-md-block">
                        <button type="button" class="btn btn-dark btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="icofont icofont-filter"></span> Sort by Products &nbsp;&nbsp;
                        </button>
                        <div class="dropdown-menu dropdown-menu-right">
                           <a class="dropdown-item" href="#">Relevance</a>
                           <a class="dropdown-item" href="#">Price (Low to High)</a>
                           <a class="dropdown-item" href="#">Price (High to Low)</a>
                           <a class="dropdown-item" href="#">Discount (High to Low)</a>
                           <a class="dropdown-item" href="#">Name (A to Z)</a>
                        </div>
                     </div>
                     <h5 class="mb-1 text-dark">Topwear</h5>
                     <a href="#"><span class="icofont icofont-ui-home"></span> Home</a> <span class="icofont icofont-thin-right"></span> <a href="#">Topwear</a> <span class="icofont icofont-thin-right"></span> <span>Sweatshirts</span>
                  </div>
                  <div class="row">
                     <div class="col-6 col-md-4">
                        <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                           <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                           <a href="#">
                           <span class="badge badge-danger">NEW</span>
                           <img src="img/item/1.jpg" class="card-img-top" alt="..."></a>
                           <div class="card-body">
                              <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                              <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span></div>
                              <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                           </div>
                        </div>
                     </div>
                     <div class="col-6 col-md-4">
                        <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                           <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                           <a href="#">
                           <span class="badge badge-success">50% OFF</span>
                           <img src="img/item/2.jpg" class="card-img-top" alt="..."></a>
                           <div class="card-body">
                              <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                              <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span></div>
                              <p class="f-14 mb-0 text-dark">$ 135.00 <span class="bg-danger  rounded-sm pl-1 ml-1 pr-1 text-white small"> 50% OFF</span></p>
                           </div>
                        </div>
                     </div>
                     <div class="col-6 col-md-4">
                        <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                           <span class="like-icon"><a class="active" href="#"> <i class="icofont icofont-heart"></i></a></span>
                           <a href="#">
                           <span class="badge badge-danger">NEW</span>
                           <img src="img/item/3.jpg" class="card-img-top" alt="..."></a>
                           <div class="card-body">
                              <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                              <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span></div>
                              <p class="f-14 mb-0 text-dark">$ 135.00 <span class="bg-info rounded-sm pl-1 ml-1 pr-1 text-white small"> 50% OFF</span></p>
                           </div>
                        </div>
                     </div>
                     <div class="col-6 col-md-4">
                        <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                           <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                           <a href="#">
                           <span class="badge badge-success">50% OFF</span>
                           <img src="img/item/4.jpg" class="card-img-top" alt="..."></a>
                           <div class="card-body">
                              <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                              <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span></div>
                              <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                           </div>
                        </div>
                     </div>
                     <div class="col-6 col-md-4">
                        <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                           <a href="#">
                           <span class="badge badge-danger">NEW</span>
                           <img src="img/item/5.jpg" class="card-img-top" alt="..."></a>
                           <div class="card-body">
                              <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                              <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span></div>
                              <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                           </div>
                        </div>
                     </div>
                     <div class="col-6 col-md-4">
                        <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                           <span class="like-icon"><a class="active" href="#"> <i class="icofont icofont-heart"></i></a></span>
                           <a href="#">
                           <span class="badge badge-success">50% OFF</span>
                           <img src="img/item/6.jpg" class="card-img-top" alt="..."></a>
                           <div class="card-body">
                              <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                              <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span></div>
                              <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-12 text-center load-more">
                        <button class="btn btn-primary btn-sm" type="button" disabled>
                        <span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>
                        Loading...
                        </button>  
                     </div>
                  </div>
               </div>
            </div>
         </div>
         </div>
      </section>
   
      <div class="copyright bg-light py-3">
         <div class="container">
            <div class="row">
               <div class="col-md-6 d-flex align-items-center">
                  <p class="mb-0">© Copyright 2019 <a href="#">Chpoee</a> . All Rights Reserved
                  </p>
               </div>
               <div class="col-md-6 text-right">
                  <img class="img-fluid" src="img/payment_methods.png">
               </div>
            </div>
         </div>
      </div>
      <div class="cart-sidebar">
         <div class="cart-sidebar-header">
            <h5>
               My Cart <span class="text-info">(5 item)</span> <a data-toggle="offcanvas" class="float-right" href="#"><i class="icofont icofont-close-line"></i>
               </a>
            </h5>
         </div>
        
         
      </div>
      <!-- Bootstrap core JavaScript -->
      <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <!-- select2 Js -->
      <script src="vendor/select2/js/select2.min.js"></script>
      <!-- Owl Carousel -->
      <script src="vendor/owl-carousel/owl.carousel.js"></script>
      <!-- Custom scripts for all pages-->
      <script src="js/custom.js"></script>
   </body>
</html>