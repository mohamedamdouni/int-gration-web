
import React from 'react';
import './styles.css';


class ShoppingCart extends React.Component {
  render() {
    const { cart, total, handleCheckout, handleRemoveItem } = this.props;
  
    return (
        
      <div  class="shopping-cart">
        <h2 >Shopping Cart</h2>
        {cart.map((item, index) => (
          <div key={index}>
            {item.name} - ${item.price}{' '}
            <button onClick={() => handleRemoveItem(index)}>Remove</button>
          </div>
        ))}
        <p>Total: ${total}</p>
        <button onClick={handleCheckout}>Checkout</button>
      </div>
    );
  }
}

export default ShoppingCart;
