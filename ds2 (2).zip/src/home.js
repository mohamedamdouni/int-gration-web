import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Slider from 'react-slick';
const settings = {
    // Your slider configuration options go here
    // For example:
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
const Home = () => {
  return (
    
    <div>
        
        <div className="App">
      
      <div>
      <div className="py-0">
      <div>
      <Slider {...settings}>
        <div>
          <img
            className="img-fluid mx-auto"
            height="300px"
            width="1000px"
            src="img/banner/1.webp"
            alt=""
          />
        </div>
        <div>
          <img
            className="img-fluid mx-auto"
            height="300px"
            width="1000px"
            src="img/banner/pot1.webp"
            alt=""
          />
        </div>
      </Slider>
    </div>
</div>


      <section className="py-5">
        <div className="container">
          <div className="row">
            <div className="col-4">
              <div className="offers-block">
                <a href="#">
                  <img className="img-fluid" height={300} src="img/of6.jpg" alt="" />
                </a>
              </div>
            </div>
            <div className="col-4">
              <div className="offers-block">
                <a href="#">
                  <img className="img-fluid mb-3" src="img/of1.jpg" alt="" />
                </a>
              </div>
              <div className="offers-block">
                <a href="#">
                  <img className="img-fluid" src="img/of2.webp" alt="" />
                </a>
              </div>
            </div>
            <div className="col-4">
              <div className="offers-block">
                <a href="#">
                  <img className="img-fluid" height={200} src="img/of3.jpg" alt="" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>


      <section class="product-list pbc-5 pb-4 pt-5 bg-light">
      <div class="container">
         <h6 class="mt-1 mb-0 float-right"><a href="#">View All Items</a></h6>
         <h4 class="mt-0 mb-3 text-dark font-weight-normel">Best Selling Items</h4>
         <div class="row">
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                    <span class="badge badge-danger">NEW</span>
                    <img src="img/item/1.png" height={350}class="card-img-top" alt="..."></img></a>
                                                                  

                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                     <span class="badge badge-success">50% OFF</span>
                     <img src="img/item/2.png" height={350} class="card-img-top" alt="..."></img></a>
                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$ 135.00 <span class="text-black-50"><del>$500.00 </del></span> <span class="bg-danger  rounded-sm pl-1 ml-1 pr-1 text-white small"> 50% OFF</span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a class="active" href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                     <span class="badge badge-danger">NEW</span>
                     <img src="img/item/3.png" height={350}class="card-img-top" alt="..."></img></a>
                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$ 135.00 <span class="text-black-50"><del>$500.00 </del></span> <span class="bg-info rounded-sm pl-1 ml-1 pr-1 text-white small"> 50% OFF</span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                     <span class="badge badge-success">50% OFF</span>
                     <img src="img/item/4.png" height={350} class="card-img-top" alt="..."></img></a>
                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <a href="#">
                     <span class="badge badge-danger">NEW</span>
                     <img src="img/item/5.png" height={350} class="card-img-top" alt="..."></img></a>
                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a class="active" href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                     <span class="badge badge-success">50% OFF</span>
                     <img src="img/item/6.png" height={350} class="card-img-top" alt="..."></img></a>
                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                     <span class="badge badge-danger">NEW</span>
                     <img src="img/item/7.png" height={350} class="card-img-top" alt="..."></img></a>
                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
            <div class="col-6 col-md-3">
               <div class="card list-item bg-white rounded overflow-hidden position-relative shadow-sm">
                  <span class="like-icon"><a href="#"> <i class="icofont icofont-heart"></i></a></span>
                  <a href="#">
                     <span class="badge badge-success">50% OFF</span>
                     <img src="img/item/8.png" height={350} class="card-img-top" alt="..."></img></a>
                  <div class="card-body">
                     <h6 class="card-title mb-1">Floret Printed Ivory Skater Dress</h6>
                     <div class="stars-rating"><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star active"></i><i class="icofont icofont-star"></i> <span>613</span>
                     </div>
                     <p class="mb-0 text-dark">$135.00 <span class="text-black-50"><del>$500.00 </del></span></p>
                  </div>
               </div>
            </div>
         </div>
      </div>
      
   </section>
    </div>
      
    </div>
  );
}

export default Home;