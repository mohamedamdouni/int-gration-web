 import logo from './logo.svg';
import Slider from 'react-slick';

import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import ProductGrid from './productgrid';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';



import './App.css';
import Home from './home';
import Contact from './contact';


function App() {
  
   const settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1,
    };
    return (
      <div className="App">
         <Router>
      <div class="main-nav shadow-sm">
         <nav class="navbar navbar-expand-lg navbar-light bg-white pt-0 pb-0">
            <div class="container">
               <a class="navbar-brand" href="index.html">
                  <img src="img/YUF-TEN.png" width={200} alt="gurdeep osahan designer"></img>
               </a>
               <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
               </button>
               <div class="collapse navbar-collapse" id="navbarSupportedContent">
               
                     <ul class="navbar-nav mr-auto main-nav-left">
                        <li class="nav-item">
                           <a class="nav-link" href="index.html"><i class="icofont-ui-home"></i></a>
                        </li>
                        <li class="nav-item dropdown mega-drop-main">
                           <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Decoration
                           </a>
                           <div class="dropdown-menu mega-drop  shadow-sm border-0" aria-labelledby="navbarDropdown">
                              <div class="row ml-0 mr-0">
                                 <div class="col-lg-2 col-md-2">
                                    <div class="mega-list">
                                       <a class="mega-title" href="product-grid.html">Home Decoration</a>
                                       <Link to="/home">Home</Link>
                                       <Link to="/product-grid">Product Grid</Link>

                                       
                                       <a href="product-grid.html">Garden</a>
                                       
                                    
                                    </div>
                                 </div>
                              
                              </div>
                           </div>
                        </li>
                        <li class="nav-item dropdown mega-drop-main">
                           <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Art</a>
                           <div class="dropdown-menu mega-drop  shadow-sm border-0" aria-labelledby="navbarDropdown">
                              <div class="row ml-0 mr-0">
                                 <div class="col-lg-3 col-sm-3 col-xs-3 col-md-3">
                                    <div class="mega-list">
                                       <a class="mega-title" href="product-grid.html">Pottery </a>
                                       <a href="product-grid.js">Bowel</a>
                                       <a href="product-grid.js">Cups</a>
                                    
                                    </div>
                                 </div>
                              
                              </div>
                           </div>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="product-grid.html">SALE</a>
                        </li>
                        <li class="nav-item dropdown">
                           <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              PAGES
                           </a>
                           <div class="dropdown-menu dropdown-menu-right shadow-sm border-0">
                              <a class="dropdown-item" href="product-grid.html">Product List</a>
                              <a class="dropdown-item" href="product-detail.html">Product Detail</a>
                              <a class="dropdown-item" href="checkout.html">Checkout</a>
                              <a class="dropdown-item" href="profile.html">My Account</a>
                              <a class="dropdown-item" href="about-us.html">About Us</a>
                              <a class="dropdown-item" href="faq.html">FAQ</a>
                              <a class="dropdown-item" href="contact-us.html">Contact Us</a>
                           </div>
                        </li>
                     </ul>
               
               
                  <form class="form-inline my-2 my-lg-0 top-search">
                     <button class="btn-link" type="submit"><i class="icofont-search"></i></button>
                     <input class="form-control mr-sm-2" type="search" placeholder="Search for products, brands and more" aria-label="Search"/>
                  </form>
                  <ul class="navbar-nav ml-auto profile-nav-right">
                     <li class="nav-item">
                        <a href="#" data-target="#login" data-toggle="modal" class="nav-link ml-0">
                           <i class="icofont-ui-user"></i> Login/Sign Up
                        </a>
                     </li>
                     <li class="nav-item cart-nav">
                        <a data-toggle="offcanvas" class="nav-link" href="#">
                           <i class="icofont-basket"></i> Cart
                           <span class="badge badge-danger">5</span>
                        </a>
                     </li>
                  </ul>
               </div>
            </div>
         </nav>
      </div>
      <div class="container">
      <Routes>
         <Route path="/home" element={<Home />} />
          <Route path="/product-grid" element={<ProductGrid />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </div>
      </Router>
    </div>
    );
}

export default App;
