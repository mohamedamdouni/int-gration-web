// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCnX_2c6GJUJyFoV4KsyH6hteMDjfh8Hg8",
  authDomain: "ds2base.firebaseapp.com",
  projectId: "ds2base",
  storageBucket: "ds2base.appspot.com",
  messagingSenderId: "270523631289",
  appId: "1:270523631289:web:677135fec750a0e10fbd68",
  measurementId: "G-9GR0SR38R4"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);